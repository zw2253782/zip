/*
#include <opencv2/opencv.hpp>
//#include <opencv2/highgui/highgui.hpp>
//#include <opencv2/core/core.hpp>
#include <opencv2/core.hpp>
#include <opencv2/core/utility.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
*/

#include "headers.h"

#include "remote_controller.h"
#include "udp_socket.h"
#include "utility.h"
#include "packet_aggregator.h"


void startThreads(int argc, char** argv);


int main( int argc, char** argv )
{
  startThreads(argc, argv);

  return 0;
}


void startThreads(int argc, char** argv) {
  /*if there is an error about bind address or address already used
   *reconnect the tethering mode on the phone(turn off then turn on)
  */

  RemoteController* dataPool = new RemoteController(argc, argv);

  int num = 3;
  pthread_t threads[num];

  pthread_create (&(threads[0]), NULL, &RemoteController::GstreamerReceiver, dataPool);
  pthread_create (&(threads[1]), NULL, &RemoteController::ControlPanel, dataPool);
  pthread_create (&(threads[2]), NULL, &RemoteController::VideoFrameProcesser, dataPool);
  if (dataPool->use_tcp_) {
    pthread_create (&(threads[3]), NULL, &RemoteController::TCPReceiverForCar, dataPool);
  } else {
    pthread_create (&(threads[3]), NULL, &RemoteController::UDPReceiverForCar, dataPool);
  }
  for(int i = 0; i < num; ++i) {
    pthread_join(threads[i], NULL);
  }

  delete dataPool;
}











